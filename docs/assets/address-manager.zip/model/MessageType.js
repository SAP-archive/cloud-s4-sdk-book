"use strict";

sap.ui.define([
], function () {
    return {
        NOTHING_SELECTED: 0,
        NOTHING_AVAILABLE: 1,
        NOTHING_FOUND: 2
    };
});
